ContainerView と UIPageViewController を使って画面の一部をページングさせるサンプル

http://crossbridge-lab.hatenablog.com/entry/2015/12/26/210600
